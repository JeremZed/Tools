class Project():
    def __init__(self):
        self.version = "ma version ici !"